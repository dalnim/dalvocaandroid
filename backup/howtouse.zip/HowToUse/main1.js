/**
 * 
 */

function readFile() {
	alert('readfile');
	var file = $("#filepath").prop("files")[0];
    $("#fileName").text(file.name);
    $("#fileSize").text("(" + file.size + "byte)");

    var reader = new FileReader();

   reader.readAsText(file, $("#encoding option:selected").val());
   reader.onload = function() {
       $("#comment").val($("#comment").val() + "\n\n" + reader.result);
  };
  reader.onerror = function(evt) {
      alert(evt.target.error.code);
  };

};

function fnGetShowPronounce() {
	var uid = "${sessionScope.UID}";
	$.ajax({
		url: 'getShowPronounce',
		data: ({uid : uid}),
			success:function(data) { 				
				if (data == "1") { 	 					
					$("#chk_SHOW_PRONOUNCE").attr("checked", true);				 				
				} else { 					
					$("#chk_SHOW_PRONOUNCE").attr("checked", false);
				} 				
		}, error: function (ajaxContext) {
			$("#chk_SHOW_PRONOUNCE").attr("checked", true);
//		        alert(ajaxContext.responseText)
	    }
	});
}	

function fnGetShowMeaning() {
	alert("fnGetShowMeaning");
	var uid = "${sessionScope.UID}";
	$.ajax({
		url: 'getShowMeaning',
		data: ({uid : uid}),
			success:function(data) {
				if (data == "1") { 					
					$("#chk_SHOW_MEANING").attr("checked", true);				 				
				} else { 					
					$("#chk_SHOW_MEANING").attr("checked", false);
				} 				
		}, error: function (ajaxContext) {
			$("#chk_SHOW_MEANING").attr("checked", true);
//		        alert(ajaxContext.responseText)
	    }
	});
}	

//function isEmpty(str) {
//	  return typeof str == 'string' && !str.trim() || typeof str == 'undefined' || str === null;
//}
//
